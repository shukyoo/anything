<?php namespace App\Console\Commands;

use App\Models\Migration;
use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class Test extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'test';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Command description.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function fire()
	{
	    /*
	    Migration::create(array(
	        'kind' => 'cn',
            'project' => 'mall',
            'version' => '1.2.2'
        ));
	    */
        $migrated = Migration::where(['kind' => 'cn', 'project' => 'mall'])->lists('version');
        print_r($migrated);

	}


}
