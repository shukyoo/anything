<?php namespace App\Models;

class Pbreserve extends BaseModel
{
    protected $table = 'pbreserve';
    protected $guarded = ['id'];

}