<?php namespace App\Models;

class Migration extends BaseModel
{
    protected $table = 'migration';
    protected $guarded = ['id'];

    public function setUpdatedAt($value) {
        // Do nothing.
    }

    public function getUpdatedAtColumn() {
        return null;
    }
}