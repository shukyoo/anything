<?php namespace App\Models;

class Project extends BaseModel
{
    protected $table = 'project';
    protected $guarded = ['id'];
    public $timestamps = false;

    public static function getName($key = null)
    {
        $projects = Project::get(['project', 'name']);
        $data = [];
        foreach ($projects as $prj) {
            $data[$prj->project] = $prj->name;
        }
        //$data = Project::get(['project', 'name'])->pluck('name', 'project')->all();
        if ($key) {
            return isset($data[$key]) ? $data[$key] : null;
        } else {
            return $data;
        }
    }
}