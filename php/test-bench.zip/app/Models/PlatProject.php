<?php namespace App\Models;

class PlatProject extends BaseModel
{
    protected $table = 'plat_project';
    protected $guarded = ['id'];
    public $timestamps = true;

}