<?php namespace App\Models;

class Plat extends BaseModel
{
    protected $table = 'plat';
    protected $guarded = ['id'];
    public $timestamps = false;

}