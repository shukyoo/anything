<?php namespace App\Http\Requests;

class ReserveRequest extends Request
{
    public function rules()
    {
        return [
            'start_date' => 'required|date_format:Y-m-d|after:today',
            'end_date' => 'required|date_format:Y-m-d|after:start_date'
        ];
    }

    public function authorize()
    {
        return true;
    }
}
