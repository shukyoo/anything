<?php namespace App\Http\Requests;

class FlowNotifyRequest extends Request
{
    public function rules()
    {
        return [
            'flow' => 'required',
            'project' => 'required',
            'units' => 'required'
        ];
    }

    public function authorize()
    {
        return true;
    }
}
