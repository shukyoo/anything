<?php namespace App\Http\Requests;

class SqlRequest extends Request
{
    public function rules()
    {
        return [
            'project' => 'required',
            'sql' => 'required'
        ];
    }

    public function authorize()
    {
        return true;
    }
}
