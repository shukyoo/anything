<?php
Route::get('/', ['as' => 'index', 'uses' => 'IndexController@index']);
Route::get('/note', ['as' => 'note', 'uses' => 'IndexController@note']);
Route::get('/login', ['as' => 'login', 'uses' => 'IndexController@login']);
Route::post('/dologin', ['as' => 'dologin', 'uses' => 'IndexController@dologin']);


Route::group(['prefix' => 'deploy'], function(){
    Route::get('panel/{plat}', ['as' => 'deploy-panel', 'uses' => 'DeployController@panel']);
    Route::get('sync/{plat}/{project}', ['as' => 'deploy-sync', 'uses' => 'DeployController@sync']);
    Route::get('switch/{plat}/{project}', ['as' => 'deploy-switch', 'uses' => 'DeployController@svnSwitch']);
});

Route::get('/sql', ['as' => 'sql', 'uses' => 'SqlController@index']);
Route::post('/sql', ['as' => 'sql-submit', 'uses' => 'SqlController@submit']);
Route::get('/test', ['as' => 'test-index', 'uses' => 'TestController@index']);

// migration
Route::get('/migration/{kind}', ['as' => 'migration', 'uses' => 'MigrationController@index']);
Route::get('/migration/{kind}/{project}', ['as' => 'migration-submit', 'uses' => 'MigrationController@submit']);

// 流程通知
Route::any('/flow/notify', ['as' => 'flow-notify', 'uses' => 'FlowController@notify']);


Route::group(['prefix' => 'pbrsv'], function(){
    Route::get('/', ['as' => 'pbrsv-index', 'uses' => 'PbreserveController@index']);
    Route::post('add', ['as' => 'pbrsv-add', 'uses' => 'PbreserveController@add']);
    Route::get('delete/{id}', ['as' => 'pbrsv-del', 'uses' => 'PbreserveController@del']);
});


// 美分
Route::group(['prefix' => 'usdeploy'], function(){
    Route::get('/', ['as' => 'usdeploy-index', 'uses' => 'USDeployController@index']);
    Route::get('panel/{plat}', ['as' => 'usdeploy-panel', 'uses' => 'USDeployController@panel']);
    Route::get('sync/{plat}/{project}', ['as' => 'usdeploy-sync', 'uses' => 'USDeployController@sync']);
    Route::get('switch/{plat}/{project}', ['as' => 'usdeploy-switch', 'uses' => 'USDeployController@svnSwitch']);
});