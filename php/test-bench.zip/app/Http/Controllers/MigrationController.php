<?php namespace App\Http\Controllers;

use App\Models\Migration;
use App\Models\Project;
use Illuminate\Support\Facades\DB;
use PDO;

class MigrationController extends Controller
{
    const CHANGELOGS_PATH = '/home/mall/deploy/changelogs';
    //const CHANGELOGS_PATH = 'E:\www\hikvision\tool\changelogs';

    /**
     * @var /PDO[]
     */
    protected $pdos = [];


    public function index($kind)
    {

        $projects = Project::where('is_migration', 1)->select('project', 'name')->get()->keyBy('project');

        /*
        // 暂时去除海外项目
        $strips = ['subscribe'];
        foreach ($projects as $k => $v) {
            if (strpos($k, 'ovs_') !== false || strpos($k, 'ezviz') !== false || strpos($k, 'static') !== false || strpos($k, 'front') !== false) {
                unset($projects[$k]);
            }
        }
        */

        /*
        $projects = array(
            'mall' => '商城',
            'ecadmin' => '大后台',
            'order' => '订单服务'
        );
        */
        $projects = $projects->toArray();
        foreach ($projects as &$item) {
            $item = $item['name'];
        }

        return view('migration.index', compact('projects'));
    }

    public function submit($kind, $project)
    {
        set_time_limit(1800);
        $kind = trim($kind);
        $project = trim($project);
        $output = [];

        if (!$project) {
            $output[] = '参数错误，请返回重试';
        } else {

            $path = self::CHANGELOGS_PATH .'/'. $project;

            // 执行svn up
            exec('svn up '. $path .' 2>&1');

            // 遍历项目changelog目录
            $dirs = $this->getDirs($path);

            // 获取当前项目已记录的migration
            $migrated = Migration::where(['kind' => $kind, 'project' => $project])->lists('version');

            // 比较后剩余为待处理的migration，如果目录里存在.sql文件，则处理，否则只记录（主要用于下次不会重复判断）
            $unmigrated = array_diff($dirs, $migrated);

            // 通过svn版本进行重新排序
            $unmigrated = $this->sortByRevision($path, $unmigrated);


            // 跟当前已记录的migration版本比较，把没有记录的按svn版本号先后顺序逐个执行
            foreach ($unmigrated as $dir) {
                $result = ['version' => $dir];
                // 查找目录下的sql文件，并对sql进行处理
                $sql_files = glob($path .'/'. $dir .'/*.sql');
                if (!empty($sql_files)) {
                    foreach ($sql_files as $sql_file) {
                        $file_result = ['file' => $sql_file];
                        // 执行sql
                        $file_result['result'] = $this->handleSqlFile($project, $sql_file);
                        $result['files'][] = $file_result;
                    }
                }
                // 记录到数据库
                Migration::create(array(
                    'kind' => $kind,
                    'project' => $project,
                    'version' => $dir
                ));
                $output[] = $result;
            }

        }

        return view('migration.result', compact('output'));
    }



    /**
     * 处理每个sql文件
     * 去掉use，获取到里面的sql进行执行
     */
    protected function handleSqlFile($project, $sql_file)
    {
        $f = fopen($sql_file, 'rb');
        $sql = '';
        $sqls = [];
        while (!feof($f)) {
            $line_raw = fgets($f);
            $line = trim($line_raw);
            // use跳过
            // create database跳过
            // drop table跳过
            // 注释跳过
            if (
                strtolower(substr($line, 0, 3)) == 'use' ||
                preg_match('/create\s+database/i', strtolower($line)) ||
                preg_match('/drop\s+table/i', strtolower($line)) ||
                substr($line, 0, 2) == '--')
            {
                continue;
            }
            $sql .= $line_raw;
            // 如果最后是分号则表示sql完结
            if (substr($line, -1) == ';') {
                $sqls[] = $sql;
                $sql = '';
            }
        }
        $result = [];
        foreach ($sqls as $sql) {
            $result[] = array(
                'sql' => $sql,
                'result' => $this->runSql($project, $sql)
            );
        }
        return $result;
    }

    /**
     * 执行每一条sql
     */
    protected function runSql($project, $sql)
    {
        if (empty($this->pdos)) {
            $config = \Config::get('database.connections.mysql');
            foreach ($this->getProjectDatabases($project) as $dbname) {
                $dsn = 'mysql:dbname='. $dbname .';host='. $config['host'];
                $this->pdos[$dbname] = new PDO($dsn, $config['username'], $config['password'], [PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'", PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            }
        }
        $result = [];
        foreach ($this->pdos as $dbname => $pdo) {
            try {
                $pdo->exec($sql);
                $result[] = $dbname .' success';
            } catch (\Exception $e) {
                $result[] = $dbname .' fail: '. $e->getMessage();
                continue;
            }
        }
        return $result;
    }

    /**
     * 基于所有数据库找到匹配的项目数据库
     * 项目数据库规则： test(xx)_name 如 test01_mall
     */
    protected function getProjectDatabases($project)
    {
        // 获取所有数据库
        $databases = $this->getDatabases();
        // 进行数据库匹配
        $matches = [];
        foreach ($databases as $db) {
            if (preg_match('/test(\d+)_'. $project .'/i', $db)) {
                $matches[] = $db;
            }
        }
        return $matches;
    }


    /**
     * 获取所有数据库
     */
    protected function getDatabases()
    {
        $databases = [];
        $res = DB::select('show databases');
        foreach ($res as $item) {
            $databases[] = $item->Database;
        }
        return $databases;
    }

    /**
     * 获取指定路径下的所有子目录名称
     * 按时间先后顺序进行排序，早的排在上面
     */
    protected function getDirs($path)
    {
        $path = rtrim($path, '/');
        $dirs = glob($path .'/*', GLOB_ONLYDIR);
        usort($dirs, function($a, $b) {
            return filemtime($a) > filemtime($b);
        });
        foreach ($dirs as $k => $dir) {
            $name = ltrim(strrchr($dir, '/'), '/');
            if ($name != '.svn') {
                $dirs[$k] = $name;
            }
        }
        return $dirs;
    }


    /**
     * 基于svn版本对目录进行排序，早的排在上面
     */
    protected function sortByRevision($path, $dirs)
    {
        if (empty($dirs)) {
            return [];
        }
        $dd = [];
        foreach ($dirs as $dir) {
            $dir_path = rtrim($path, '/') .'/'. $dir;
            exec('svn info '. $dir_path .' 2>&1', $out);
            $out = implode("\n", $out);
            preg_match('/Last Changed Rev:\s*(\d+)/i', $out, $match);
            $revision = empty($match[1]) ? '1' : trim($match[1]);
            $dd[$dir] = $revision;
        }
        asort($dd);
        return array_keys($dd);
    }

}
