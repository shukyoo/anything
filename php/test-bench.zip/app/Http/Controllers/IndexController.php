<?php namespace App\Http\Controllers;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index(Request $request)
    {
        //$username = $request->cookie('username');
        $username = isset($_COOKIE['username']) ? trim($_COOKIE['username']) : '';
        if (!$username) {
            return redirect('login');
        }
        return view('index');
    }

    public function note()
    {
        return view('note');
    }

    public function login()
    {
        return view('login');
    }

    public function dologin(Request $request)
    {
        setcookie('username', $request->get('username'), time()+518400 * 60);
        return redirect('/');
        //return redirect('/')->withCookie(cookie('username', $request->get('username'), 518400));
    }
}
