<?php namespace App\Http\Controllers;

use App\Http\Requests\MigrationRequest;
use Illuminate\Support\Facades\DB;
use PDO;
use App\Models\PlatProject;

class TestController extends Controller
{
    public function index()
    {
        exec('svn up /home/mall/deploy/test06/ocs');
    }

}
