<?php namespace App\Http\Controllers;

use App\Http\Requests\SqlRequest;
use PDO;
use App\Models\PlatProject;

class SqlController extends Controller
{
    public function index()
    {
        return view('sql.index');
    }

    public function submit(SqlRequest $request)
    {
        $project = $request->project;
        $sql = $request->sql;
        $output = [];

        if (!$project || !$sql) {
            $output[] = '参数错误，请返回重试';
        } else {

            $dbnames = PlatProject::where('project', '=', $project)->where('dbname', '!=', '')->lists('dbname');
            $config = \Config::get('database.connections.mysql');
            foreach ($dbnames as $dbname) {
                try {
                    $dsn = 'mysql:dbname='. $dbname .';host='. $config['host'];
                    $pdo = new PDO($dsn, $config['username'], $config['password'], [PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'", PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                    $pdo->exec($sql);
                    $output[] = $dbname .' success';
                } catch (\Exception $e) {
                    $output[] = $dbname .' fail: '. $e->getMessage();
                    continue;
                }
            }

        }

        return view('sql.result', compact('output'));
    }
}
