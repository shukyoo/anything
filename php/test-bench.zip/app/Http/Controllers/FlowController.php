<?php namespace App\Http\Controllers;
use App\Http\Requests\FlowNotifyRequest;
use Illuminate\Http\Request;

class FlowController extends Controller
{
    public function notify(Request $request)
    {
        $data = $request->all();
        if (empty($data['flow']) || empty($data['project']) || empty($data['units'])) {
            return response()->json(array(
                'code' => '-1',
                'msg' => '参数无效'
            ));
        }
        file_put_contents('/tmp/flow.log', json_encode($request->all(), JSON_UNESCAPED_UNICODE) ."\n", FILE_APPEND);
        return response()->json(array(
            'code' => '1',
            'msg' => 'success'
        ));
    }
}
