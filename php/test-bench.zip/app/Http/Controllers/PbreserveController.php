<?php namespace App\Http\Controllers;

use App\Http\Requests\ReserveRequest;
use PDO;
use App\Models\Pbreserve;

class PbreserveController extends Controller
{
    protected $_username = '';

    public function __construct()
    {
        $this->_username = isset($_COOKIE['username']) ? trim($_COOKIE['username']) : '';
    }

    public function index()
    {
        $list = Pbreserve::orderBy('id', 'DESC')->limit(10)->get();
        return view('pbreserve.index', ['list' => $list, 'username' => $this->_username]);
    }

    public function add(ReserveRequest $request)
    {
        $pbreserve = new Pbreserve();
        $pbreserve->name = $this->_username;
        $pbreserve->start_date = $request->start_date;
        $pbreserve->end_date = $request->end_date;
        $pbreserve->save();

        return redirect()->route('pbrsv-index');
    }

    public function del($id)
    {
        $item = Pbreserve::find($id);
        if ($item && $item->name == $this->_username) {
            $item->delete();
        }
        return redirect()->route('pbrsv-index');
    }

}
