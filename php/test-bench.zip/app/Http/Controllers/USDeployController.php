<?php namespace App\Http\Controllers;

use App\Models\PlatProject;
use App\Models\Project;

class USDeployController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function panel($plat)
    {
        // 获取所有plat_project，按plat为key索引
        $plat_projects = PlatProject::where(['is_show' => 1, 'kind' => 'us'])->get(['id', 'plat', 'project', 'svn_title', 'svn_url'])->groupBy('plat')->toArray();

        // 所有projects名称
        $projects = Project::getName();

        return view('usdeploy.panel', compact('plat', 'plat_projects', 'projects'));
    }


    public function sync($plat, $project)
    {
        $do = \Request::get('do', 0);

        if (!$do) {
            $show = '正在同步中......';
        } else {
            if (!$plat || !$project) {
                $show = '请指定项目和分支';
            } else {
                $output = [];
                /*
                if ($project == 'mall') {
                    $this->_sync($plat, 'mall', $output);
                    $this->_sync($plat, 'mall_statics', $output);
                } elseif ($project == 'subscribe') {
                    $this->_sync($plat, 'subscribe', $output);
                    $this->_sync($plat, 'subscribe_statics', $output);
                } else {
                    $this->_sync($plat, $project, $output);
                }
                */

                $this->_sync($plat, $project, $output);
                $show = is_array($output) ? implode('<br />', $output) : $output;
            }
        }

        return view('usdeploy.show', compact('show', 'do'));
    }

    public function svnSwitch($plat, $project)
    {
        $svn_title = \Request::get('title');
        $svn_url = \Request::get('url');
        $do = \Request::get('do', 0);

        if (!$do) {
            $show = '正在切换中......';
        } elseif (!$plat || !$project || !$svn_title || !$svn_url) {
            $show = '请指定项目和分支和svn url';
        } else {
            $output = [];

            // 如果商城是php+static整体切，则要执行两个
            /*
            if ($project == 'mall') {
                $this->_switch($plat, 'mall', $svn_title, $svn_url .'/php', $output);
                $this->_switch($plat, 'mall_statics', $svn_title, $svn_url .'/statics', $output);
            } elseif ($project == 'subscribe') {
                $this->_switch($plat, 'subscribe', $svn_title, $svn_url .'/php', $output);
                $this->_switch($plat, 'subscribe_statics', $svn_title, $svn_url .'/statics', $output);
            } else {
                $this->_switch($plat, $project, $svn_title, $svn_url, $output);
            }
            */

            $this->_switch($plat, $project, $svn_title, $svn_url, $output);
            $show = implode('<br />', $output);
        }
        return view('usdeploy.show', compact('show', 'do'));
    }


    protected function _sync($plat, $project, &$output)
    {
        set_time_limit(0);
        $pp = PlatProject::where(['plat' => $plat, 'project' => $project, 'kind' => 'us'])->first();
        if (!$pp) {
            $output = $plat .' > '. $project .' not exists';
        } elseif (getSuffix($pp->svn_url) == 'zip') {
            $output = '请使用“切换”进行zip部署';
        } else {
            try {
                $pp->sync_at = date('Y-m-d H:i:s');
                $pp->save();
                exec('sh /home/mall/deploy/deploy_us.sh sync '. $plat .' '. $project .' 2>&1', $output);
            } catch (\Exception $e) {
                $output = $e->getMessage();
            }
        }
    }


    protected function _switch($plat, $project, $svn_title, $svn_url, &$output)
    {
        set_time_limit(0);
        $pp = PlatProject::where(['plat' => $plat, 'project' => $project, 'kind' => 'us'])->first();
        if (!$pp) {
            $output = $plat .' > '. $project .' not exists';
        } else {
            try {
                $dtm = date('Y-m-d H:i:s');
                $pp->username = isset($_COOKIE['username']) ? trim($_COOKIE['username']) : '';
                $pp->svn_title = trim($svn_title);
                $pp->svn_url = trim($svn_url);
                $pp->switch_at = $dtm;
                $pp->sync_at = $dtm;
                $pp->save();
                if (getSuffix($svn_url) == 'zip') {
                    exec('sh /home/mall/deploy/deploy_us.sh dzip '. $plat .' '. $project .' '. $svn_url .' 2>&1', $output);
                } else {
                    exec('sh /home/mall/deploy/deploy_us.sh switch '. $plat .' '. $project .' '. $svn_url .' 2>&1', $output);
                }
            } catch (\Exception $e) {
                $output = $e->getMessage();
            }
        }
    }

}
