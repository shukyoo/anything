<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Console Show</title>
</head>
<body style="background-color:#1E1E1E;">
<div style="color:#8CDCFE;line-height:28px">
    <?= $show ?>
</div>

<?php
if(!$do):
$to_url = $_SERVER['REQUEST_URI'] . (strpos($_SERVER['REQUEST_URI'], '?') ? '&' : '?') .'do=1';
?>
<script>
    window.location.href="<?= $to_url ?>";
</script>
<?php endif;?>
</body>
</html>
