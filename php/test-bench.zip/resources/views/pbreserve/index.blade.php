@extends('layouts.main')

@section('meta')
    <style type="text/css">
        .prj-list{list-style-type: none}
        .prj-list li{float: left; margin-right:16px}
        .prj-list label{font-weight: normal;}

        .reserve-form{margin:20px}
    </style>
@endsection

@section('content')
<?php
$projects = \App\Models\Project::getName();
$start_date = old('start_date') ?: date('Y-m-d');
$end_date = old('end_date') ?: date('Y-m-d', strtotime('tomorrow'));
?>

<div class="reserve-form">
    <form method="post" action="{{route('pbrsv-add')}}">
        <input type="hidden" name="_token" value="{{ csrf_token() }}" />
        开始时间：<input type="text" name="start_date" value="<?= $start_date ?>" />  -
        结束时间：<input type="text" name="end_date" value="<?= $end_date ?>">
        <input type="submit" value="确定">
    </form>
</div>

<div class="reserve-list">
    <ul>
        @foreach($list as $item)
            <li>{{$item['start_date']}} - {{$item['end_date']}}<span style="padding-left:20px">{{$item['name']}}</span>
                @if ($username == $item['name'])
                <a href="{!! route('pbrsv-del', ['id' => $item['id']]) !!}">[x]</a>
                @endif
            </li>
        @endforeach
    </ul>
</div>
@endsection