@extends('layouts.main')

@section('content')
<div>
    <div class="orderList">
        <ul class="nav" style="padding-top: 20px;">
            <li role="presentation" class="active" ng-controller="testcontroller" ng-repeat="item in initData">
               <span>
                   <a class="manage @{{item.name}}"  testid="@{{item.testid}}" framesrc='@{{item.frame}}' ng-click="manage()">@{{item.name}} &gt;</a>
               </span>
                <span>
                      <testtemp></testtemp>
                </span>
            </li>
        </ul>
    </div>
    <div class="framebg">
        <iframe width="100%" height="870" src="{{ route('note') }}" id="myframe" frameborder="0" scrolling="auto"></iframe>
    </div>
    <testdialog></testdialog>
</div>
@endsection