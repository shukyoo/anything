<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" ng-app="frameapp">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="stylesheet" href="{{ asset('vendor/bootstrap-3.3.5/css/bootstrap.min.css') }}">
    <script type="text/javascript" src="{{ asset('vendor/widget/jquery-1.9.1.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('vendor/widget/angular-1.4.6.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('vendor/widget/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('vendor/widget/ui-bootstrap-tpls-0.10.0.js') }}"></script>
    <script>
        <?php
        $current = [];
        ?>
        var plat = '{{ $plat }}';
        var app=angular.module('frameapp',[]);
        app.factory('initData',function(){
            var data= {

            <?php foreach($plat_projects as $k=>$prj_list):?>
            "<?= $k ?>": {
                name:'<?= $k ?>',
                    list
            :
                [
                    <?php
                    foreach($prj_list as $i=>$prj):
                    /*
                        if ($prj['project'] == 'mall') {
                            $prj['svn_url'] = substr($prj['svn_url'], 0, -4);
                        } elseif ($prj['project'] == 'subscribe') {
                            $prj['svn_url'] = substr($prj['svn_url'], 0, -4);
                        }
                    */
                    ?>
                    {
                        platform: "<?= $projects[$prj['project']] ?>",
                        nowProject: "<?= $prj['svn_title'] ?> <?= $prj['username'] ?>",
                        svn: "...<?= substr($prj['svn_url'], 35); ?>",
                        switch: '',
                        flag: '<?= $prj['project'] ?>',
                        sync: "<?= route('usdeploy-sync', ['plat' => $k, 'project' => $prj['project']]) ?>"
                    }<?php end($prj_list);if($i != key($prj_list))echo ','; ?>
                    <?php endforeach;?>
                ]
            }
            <?php end($plat_projects);if($k != key($plat_projects))echo ','; ?>
            <?php endforeach;?>

        };
            return data;
        }).controller('frameCrl',function($scope,$element,initData){
            var search=window.location.search,testid='',testplatform='';
            if(search.indexOf("p=")>=0){
                testid=search.substr(search.indexOf("p=")+2,search.indexOf("p=")+8);
                console.log(testid);
            }

            $scope.initData=initData[plat].list;
            $scope.name=initData[plat].name;
            $scope.el=$element;
            $scope.save=function(){
                var flag = $("#i_flag").val();
                var name = $("#i_name").val();
                var svn = $("#i_svn").val();
                if (!flag || !name || !svn) {
                    alert("请填写切换分支信息");
                } else {
                    window.location.href="{{ url('usdeploy/switch') }}/{{ $plat }}/"+ flag +"?title="+ name +"&url="+svn;
                }
            }
        }).controller('itemctl',function($scope,$element,initData){
            var search=window.location.search,testid='',testplatform='';
            if(search.indexOf("p=")>=0){
                testid=search.substr(search.indexOf("p=")+2,search.indexOf("p=")+8);
                console.log(testid);
            }
            $scope.initData=initData[plat].list;
            $scope.name=initData[plat].name;
            $scope.el=$element;
            $scope.sync=function(){
                var el=this.el.find('.sync');
                var framesrc=el.attr("framesrc");
                $("#myframe").attr("src",framesrc);
            }
            $scope.switch=function(){
                var el=this.el.find('.switch');
                var flag=el.attr("flag");
                $("#i_flag").val(flag);
            }
        }).directive('testdialog',function(){
            return{
                templateUrl :  '{{ asset('template/edit_temp.html') }}',
                controller:function($scope){
                }
            }
        })
    </script>
    <title>测试平台管理</title>
    <style>
        .modal-backdrop{
            background-color: #fff;
        }
    </style>
    <script>
        $(function(){
            var search=window.location.search,testid='',testplatform='';
            if(search.indexOf("p=")>=0){
                test=search.substr(search.indexOf("p=")+2,search.indexOf("p=")+8)
                testplatform='.'+test
            }
            var testid= $(window.parent.document).contents().find(testplatform).attr("testid");
            $("#testid").val(testid);
        })
    </script>
</head>
<body ng-controller="frameCrl">
<ol class="breadcrumb">
    <li><a href="#" onclick="parent.showmsg()">首页</a></li>
    <li class="active">@{{name}}</li>
</ol>
<input type="hidden" id="testid"/>
<div style="border:1px solid #ccc;border-radius: 4px;">
    <table class="table table-striped">
        <thead>
        <tr>
            <th>平台</th>
            <th>现运行</th>
            <th>现分支</th>
            <th width="15%">操作</th>
        </tr></thead>
        <tbody>

        <tr class="infoEdit"ng-repeat="item in initData" ng-controller="itemctl">
            <td>
                <span style="line-height: 30px;">@{{item.platform}}</span>
            </td>
            <td><span style="line-height: 30px;">@{{item.nowProject}}</span></td>
            <td><span style="line-height: 30px;">@{{item.svn}}</span></td>
            <!--<td><input type="text" class="form-control title" placeholder="分支" value="@{{item.svn}}"></td>-->
            <td>
                <a class="btn btn-primary switch" href="#" role="button" data-toggle="modal" flag='@{{item.flag}}' data-target="#myModal" ng-click="switch()">切换</a>
                <a class="btn btn-primary sync" href="#" role="button" framesrc='@{{item.sync}}' ng-click="sync()">同步</a>
                <input type="hidden" value="73" id="uid">
            </td>
        </tr>
        </tbody>
    </table>
    <testdialog></testdialog>
</div>
<div class="framebg">
    <iframe width="98%" height="800" id="myframe" frameborder="0"></iframe>
</div>
</body>
</html>
