<!DOCTYPE html>
<html lang="zh-cmn-hans">
<head>
    <meta charset="UTF-8">
    <title>萤石商城</title>
    <script>
        function check(form)
        {
            username = form.elements["username"].value;
            username = username.replace(/(^\s*)|(\s*$)/g, "");
            if (username == "") {
                alert("请填写你的姓名");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
<div style="margin:20% 0 0 30%;">
<form method="post" action="{{route('dologin')}}" onsubmit="return check(this)">
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
    你的姓名：
    <input type="text" name="username" />
    <input type="submit" value="确定">
</form>
</div>
</body>
</html>