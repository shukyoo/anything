<?php
$router = \Request::route()->getName();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" ng-app="testapp">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>电商测试环境管理</title>
    <link rel="stylesheet" href="{{ asset('/vendor/bootstrap-3.3.5/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/css/main.css') }}">
    <script src="{{ asset('/vendor/widget/jquery-1.9.1.min.js') }}"></script>
    <script src="{{ asset('/vendor/widget/angular-1.4.6.min.js') }}"></script>
    <!--<script src="assets/vendors/widget/bootstrap.min.js"></script>-->
    <!--<script src="assets/vendors/widget/ui-bootstrap-tpls-0.10.0.js"></script>    -->
    @section('meta')
        <?php if(strpos($router, 'usdeploy') !== false):?>
            <script src="{{ asset('/js/usmain.js') }}" type="text/javascript"></script>
        <?php else:?>
            <script src="{{ asset('/js/main.js') }}" type="text/javascript"></script>
        <?php endif;?>
    @show


    <script type="text/javascript">
        function changeFrameHeight(){
            var ifm= document.getElementById("myframe");
            ifm.height=document.documentElement.clientHeight-86;
        }
        window.onresize=function(){ changeFrameHeight();}
        $(function(){changeFrameHeight();});
    </script>
</head>
<body >
<div class="jumbotron">
    <div style="float: left; padding-top: 10px; font-size: 16px; font-weight:bold;">测试环境管理</div>
    <ul class="navbar">
        <li<?php if($router == 'pbrsv-index')echo ' class="cur"';?>><a href="{{ route('pbrsv-index') }}">PB预约</a></li>
        <li<?php if(strpos($router, 'migration') !== false)echo ' class="cur"';?>><a href="{{ route('migration', ['kind' => 'cn']) }}">Migration</a></li>
        <li<?php if($router == 'sql')echo ' class="cur"';?>><a href="{{ route('sql') }}">SQL</a></li>
        <li<?php if(strpos($router, 'usdeploy') !== false)echo ' class="cur"';?>><a href="{{ route('usdeploy-index') }}">美分部署</a></li>
        <li<?php if($router == 'index')echo ' class="cur"';?>><a href="{{ route('index') }}">部署</a></li>
    </ul>
</div>
<div class="main" ng-controller="testListController">

    @foreach($errors->all() as $error)
        <p class="alert alert-danger">{{$error}}</p>
    @endforeach
    @yield('content')


    <div class="footer">@2015 杭州海康威视数字技术股份有限公司-萤石电商 (theme by livi)</div>
</div>
</body>
</html>
