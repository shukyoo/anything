@extends('layouts.main')

@section('meta')
    <style type="text/css">
        .prj-list{list-style-type: none}
        .prj-list li{float: left; margin-right:16px}
        .prj-list label{font-weight: normal;}
    </style>
@endsection

@section('content')
<?php
$projects = \App\Models\Project::getName();
?>
<div style="margin: 20px 0 100px 40px;">
    <form method="post" action="{{route('sql-submit')}}">
        <input type="hidden" name="_token" value="{{ csrf_token() }}" />
        <ul class="prj-list">
            <li><label><input type="radio" name="project" value="mall" checked><?= $projects['mall'] ?> mall</label></li>
            <li><label><input type="radio" name="project" value="ms_user"><?= $projects['ms_user'] ?> user</label></li>
            <li><label><input type="radio" name="project" value="ms_aftersale"><?= $projects['ms_aftersale'] ?> aftersale</label></li>
            <li><label><input type="radio" name="project" value="store"><?= $projects['store'] ?> store</label></li>
            <li><label><input type="radio" name="project" value="ocs"><?= $projects['ocs'] ?></label></li>
            <li><label><input type="radio" name="project" value="goods"><?= $projects['goods'] ?></label></li>
            <li><label><input type="radio" name="project" value="ecadmin"><?= $projects['ecadmin'] ?></label></li>
        </ul>
        <div style="clear: both;">
        <textarea name="sql" cols="120" rows="12"></textarea>
        </div>
        <div style="margin-top:4px; margin-left: 760px">
        <input type="submit" value="Submit" style="padding:10px 20px">
        </div>
    </form>
</div>
@endsection