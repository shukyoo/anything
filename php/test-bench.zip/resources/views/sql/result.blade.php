@extends('layouts.main')

@section('meta')
    <style type="text/css">
        .prj-list{list-style-type: none}
        .prj-list li{float: left; margin-right:16px}
        .prj-list label{font-weight: normal;}
    </style>
@endsection

@section('content')
<div style="margin: 20px 0 100px 40px;">
    <div style="margin-bottom: 40px;">
        <?php
        echo implode('<br>', $output);
        ?>
    </div>
    <div><a href="">&lt;&lt;返回</a></div>
</div>
@endsection