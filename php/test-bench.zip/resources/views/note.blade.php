<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>asd</title>
</head>
<body>
<div style="line-height:28px">
    <div style="font-size:30px; font-weight:bold">测试环境简要说明：</div>
    <ul style="list-style-type:disc;">
        <li>商城测试服务器IP：10.82.2.14</li>
        <li>test06是专门给前端测试的</li>
        <li>testdev是专门给后端开发使用的</li>
        <li>对应数据库：test01_mall, test01_user, test01_aftersale（test02,test03等类似）</li>
        <li>开发使用数据库：testdev_mall, testdev_user, testdev_aftersale</li>
        <li>商家后台账户：ezmall/hik123456，cjvyclxg/test123</li>
        <li>零售商账户：test_hk/hk123456</li>
    </ul>
</div>
</body>
</html>