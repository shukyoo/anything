@extends('layouts.main')

@section('meta')
    <style type="text/css">
        .prj-list{list-style-type: none}
        .prj-list li{float: left; margin-right:16px}
        .prj-list label{font-weight: normal;}
        .item{display:block; float:left; border:1px;margin:5px;padding:10px;background-color:#dff0d8}
    </style>
@endsection

@section('content')
<div style="margin: 20px 200px; height: 120px;">
    <?php foreach($projects as $key => $name):?>
    <span class="item"><a href="<?=route('migration-submit', ['kind' => 'cn', 'project' => $key])?>"><?=$name?></a></span>
    <?php endforeach;?>
</div>
@endsection