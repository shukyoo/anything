@extends('layouts.main')

@section('meta')
    <style type="text/css">
        .prj-list{list-style-type: none}
        .prj-list li{float: left; margin-right:16px}
        .prj-list label{font-weight: normal;}

        .c_version{margin-left:20px;font-size: 16px;font-weight: bold;}
        .c_file{margin-left:40px;font-weight: bold;}
        .c_sql{margin-left:60px;background-color:#faf2cc}
        .c_result{margin-left:60px;}

    </style>
@endsection

@section('content')
<div style="margin: 20px 0 100px 40px;">
    <div style="margin-bottom: 40px;">
        <?php
            if (!empty($output)) {
                foreach ($output as $item) {
                    echo '<div class="c_version">版本：'. $item['version'] .'</div>';
                    if (!empty($item['files'])) {
                        foreach ($item['files'] as $file) {
                            echo '<div class="c_file">'. strrchr($file['file'], '/') .'</div>';
                            if (!empty($file['result'])) {
                                foreach ($file['result'] as $result) {
                                    echo '<div class="c_sql"><pre>'. $result['sql'] .'</pre></div>';
                                    echo '<div class="c_result">'. implode('<br>', $result['result']) .'</div>';
                                }
                            }
                        }
                    }
                }
            } else {
                echo '<div>success!</div>';
            }
        ?>
    </div>
    <div><a href="<?=route('migration', ['kind' => 'cn'])?>">&lt;&lt;返回</a></div>
</div>
@endsection