var app=angular.module('testapp',[]);
app.factory('dataList',function(){
    return {
            initData:[
                    {
                        testid:'0',
                        name:'common',
                        frame:'deploy/panel/share',
                        sync:'sync3.php?pl=share'
                    },
                    {
                        testid:'1',
                        name:'test01',
                        frame:'deploy/panel/test01',
                        sync:'sync3.php?pl=test01'
                    },
                    {
                        testid:'2',
                        name:'test02',
                        frame:'deploy/panel/test02',
                        sync:'sync3.php?pl=test02'
                            
                    },	
                    {
                        testid:'3',
                        name:'test03',
                        frame:'deploy/panel/test03',
                        sync:'sync3.php?pl=test03'
                    },
                    {
                        testid:'4',
                        name:'test04',
                        frame:'deploy/panel/test04',
                        sync:'sync3.php?pl=test04'
                    },
                    {
                        testid:'5',
                        name:'test05',
                        frame:'deploy/panel/test05',
                        sync:'sync3.php?pl=test05'
                    },
                    {
                        testid:'6',
                        name:'test06',
                        frame:'deploy/panel/test06',
                        sync:'sync3.php?pl=test06'
                    },
                    {
                        testid:'7',
                        name:'testdev',
                        frame:'deploy/panel/testdev',
                        sync:'sync3.php?pl=testdev'
                    }
            ]
    }   
}).controller('testListController',function($scope,$element,dataList){
    $scope.initData=dataList.initData;
}).controller('testcontroller',function($scope,$element,dataList){
    $scope.btnName="关闭";
    $scope.btnFlag=false;
    $scope.el=$element;
    $scope.switch=function(){
        $scope.name=this.el.find('.switch').attr("name");
        $("#myModal").find(".username").val(this.name);
        //点击确认时，发送ajax
    };
    $scope.manage=function(){
        var el=this.el.find('.manage');
        var framesrc=el.attr("framesrc");
        $("#myframe").attr("src",framesrc);
    }
    $scope.sync=function(){
        var el=this.el.find('.sync');
        var framesrc=el.attr("framesrc");
        $("#myframe").attr("src",framesrc);
    }
})