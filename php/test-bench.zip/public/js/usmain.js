var app=angular.module('testapp',[]);
app.factory('dataList',function(){
    return {
            initData:[
                    {
                        testid:'0',
                        name:'common',
                        frame:'usdeploy/panel/share',
                        sync:'sync3.php?pl=share'
                    },
                    {
                        testid:'1',
                        name:'test01',
                        frame:'usdeploy/panel/test01',
                        sync:'sync3.php?pl=test01'
                    },
                    {
                        testid:'2',
                        name:'test02',
                        frame:'usdeploy/panel/test02',
                        sync:'sync3.php?pl=test02'
                    },
                    {
                        testid:'3',
                        name:'test03',
                        frame:'usdeploy/panel/test03',
                        sync:'sync3.php?pl=test03'
                    }
            ]
    }   
}).controller('testListController',function($scope,$element,dataList){
    $scope.initData=dataList.initData;
}).controller('testcontroller',function($scope,$element,dataList){
    $scope.btnName="关闭";
    $scope.btnFlag=false;
    $scope.el=$element;
    $scope.switch=function(){
        $scope.name=this.el.find('.switch').attr("name");
        $("#myModal").find(".username").val(this.name);
        //点击确认时，发送ajax
    };
    $scope.manage=function(){
        var el=this.el.find('.manage');
        var framesrc=el.attr("framesrc");
        $("#myframe").attr("src",framesrc);
    }
    $scope.sync=function(){
        var el=this.el.find('.sync');
        var framesrc=el.attr("framesrc");
        $("#myframe").attr("src",framesrc);
    }
})